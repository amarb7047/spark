import time
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import os

# Load accounts and proxy from JSON file
config_file = "config.json"
proxy_file = "proxy.txt"

if not os.path.exists(config_file):
    print("[ERROR] Config file not found! Ensure config.json exists.")
    exit(1)

if not os.path.exists(proxy_file):
    print("[ERROR] Proxy file not found! Ensure proxy.txt exists.")
    exit(1)

with open(config_file, "r") as file:
    config = json.load(file)

with open(proxy_file, "r") as file:
    proxy_list = [line.strip() for line in file.readlines() if line.strip()]

accounts = config.get("accounts", [])
proxy = random.choice(proxy_list) if proxy_list else None

# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--headless")  # Comment this line to see the browser
chrome_options.add_argument("--window-size=1200,800")
chrome_options.add_argument("--disable-popup-blocking")
chrome_options.add_argument("--disable-extensions")
chrome_options.add_argument("--disable-infobars")
chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)

if proxy:
    chrome_options.add_argument(f"--proxy-server={proxy}")

# Set up ChromeDriver path
chrome_driver_path = "/usr/local/bin/chromedriver"
if not os.path.exists(chrome_driver_path):
    print("[ERROR] ChromeDriver not found! Install it in /usr/local/bin/")
    exit(1)

service = Service(chrome_driver_path)

# Define website URL
url = "https://sparkchain.ai/"

def login_and_mine(email, password):
    try:
        browser = webdriver.Chrome(service=service, options=chrome_options)
        browser.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        browser.get(url)
        print(f"[INFO] Loading website for {email}...")

        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "body"))
        )
        time.sleep(random.uniform(2, 4))

        login_button = browser.find_element(By.LINK_TEXT, "Login")
        login_button.click()

        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.NAME, "email"))
        )
        email_field = browser.find_element(By.NAME, "email")
        password_field = browser.find_element(By.NAME, "password")

        email_field.send_keys(email)
        password_field.send_keys(password)
        password_field.send_keys(Keys.RETURN)

        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "reward-button"))
        )
        reward_button = browser.find_element(By.CLASS_NAME, "reward-button")
        reward_button.click()

        print(f"[INFO] Reward claimed for {email}.")
        time.sleep(random.uniform(2, 5))

        while True:
            mine_button = browser.find_element(By.CLASS_NAME, "mine-button")
            if mine_button.is_displayed():
                mine_button.click()
                print(f"[INFO] Mining started for {email}.")
                time.sleep(random.uniform(10, 20))  # Adjust timing for mining process
            else:
                print(f"[INFO] Mining unavailable for {email}. Retrying...")
                time.sleep(random.uniform(30, 60))
    except Exception as e:
        print(f"[ERROR] Error for {email}: {e}")
    finally:
        browser.quit()

for account in accounts:
    email = account.get("email")
    password = account.get("password")
    if email and password:
        login_and_mine(email, password)
    else:
        print(f"[WARNING] Skipping account due to missing credentials: {account}")

print("[INFO] All tasks completed.")
